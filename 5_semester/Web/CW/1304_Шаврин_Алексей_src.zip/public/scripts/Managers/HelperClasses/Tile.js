export class Tile {
    /* Класс тайла и координатами верхнего угла его изображения от изображения набора тайлов */
    
    constructor (img, px, py){
        this.img = img;
        this.px = px;
        this.py = py;
    }
}