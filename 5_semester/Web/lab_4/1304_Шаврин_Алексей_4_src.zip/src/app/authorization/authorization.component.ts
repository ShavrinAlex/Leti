import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './authorization.component.html',
  styleUrls: ['./authorization.component.less']
})
export class AuthorizationComponent {

}