import './App.css';
import Router from "./Router/Router";


function App() {
  return <Router></Router>
}

export default App;